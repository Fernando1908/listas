
palabras = ["Python", "Java", "C++", "Python", "JavaScript", "Python", "C#"]
contador_python = palabras.count("Python")
print(contador_python)

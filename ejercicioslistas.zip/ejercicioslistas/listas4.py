def encontrar_maximo(lista_numeros):
    if not lista_numeros:  # Verificar si la lista está vacía
        return None
    
    maximo = lista_numeros[0]  # Suponer que el primer número es el máximo
    for numero in lista_numeros[1:]:  # Comparar con los demás números
        if numero > maximo:
            maximo = numero
    return maximo

numeros = [15, 22, 8, 34, 9, 6, 17]
numero_maximo = encontrar_maximo(numeros)
print(numero_maximo)

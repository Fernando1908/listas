def eliminar_palabras_cortas(lista_palabras):
    return [palabra for palabra in lista_palabras if len(palabra) >= 4]

palabras = ["sol", "luna", "cielo", "mar", "estrella", "pez"]
palabras_filtradas = eliminar_palabras_cortas(palabras)
print(palabras_filtradas)

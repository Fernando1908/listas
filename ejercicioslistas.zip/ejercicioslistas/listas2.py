def convertir_a_mayusculas(lista_frases):
    resultado = []
    for frase in lista_frases:
        nueva_frase = ""
        for letra in frase:
            # Convertir a mayúscula si la letra está en minúscula
            if 'a' <= letra <= 'z':
                nueva_frase += chr(ord(letra) - 32)
            else:
                nueva_frase += letra
        resultado.append(nueva_frase)
    return resultado

frases = ["hola", "mundo", "python", "es", "genial"]
frases_mayusculas = convertir_a_mayusculas(frases)
print(frases_mayusculas)


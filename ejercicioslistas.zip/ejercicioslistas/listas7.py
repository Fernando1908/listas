def calcular_media(lista_numeros):
    suma = 0
    for numero in lista_numeros:
        suma += numero
    media = suma / len(lista_numeros)  
    return media

numeros = [4, 7, 2, 9, 3, 8, 5]
media_numeros = calcular_media(numeros)
print(media_numeros)

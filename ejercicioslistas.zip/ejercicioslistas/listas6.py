def invertir_lista(lista):
    inicio = 0
    fin = len(lista) - 1
    
    while inicio < fin:
        
        lista[inicio], lista[fin] = lista[fin], lista[inicio]
        inicio += 1
        fin -= 1
    
    return lista

numeros = [1, 2, 3, 4, 5]
numeros_invertidos = invertir_lista(numeros)
print(numeros_invertidos)
